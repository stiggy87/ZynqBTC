$Footmark = "FPGA_Xilinx"
$Description = "by Vivado"


#=== Resource usage ===
$SLICE = "1059"
$LUT = "3313"
$FF = "2840"
$DSP = "0"
$BRAM ="4"
$SRL ="0"
#=== Final timing ===
$TargetCP = "6.000"
$CP = "6.112"
